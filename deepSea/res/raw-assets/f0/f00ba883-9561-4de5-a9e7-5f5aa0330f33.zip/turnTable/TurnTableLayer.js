/**
 * add by wjf in 2020-08-04
 * 转盘抽奖界面
 * */
cc.Class({
    extends: cc.Component,

    properties: {
        rewardList: [cc.SpriteFrame] ,// 0 iphone 1 话费 2 流量 3 红包券
        fishSpine:cc.Node ,
        turnSpr: cc.Node ,
        nodeTip: cc.Node ,
        nodeTurn: cc.Node ,
        nodeMask: cc.Node ,
        nodeMain: cc.Node ,
        nodeRule: cc.Node ,
        nodeBottle: cc.Node ,
        progressBar: cc.Node ,
        nodePrize: cc.Node ,
        nodeDouble: cc.Node ,
        nodeBoxReward: cc.Node ,
        nodeLucky: cc.Node ,
        boxSpr: [cc.SpriteFrame] ,
        rewardFragmentSpr: [cc.SpriteFrame] ,
        titleSpr: [cc.SpriteFrame] ,
        titleLightSpr: [cc.SpriteFrame] ,
        boxPrefab: cc.Prefab ,

        rewardItemNode: cc.Node,//转盘上物品
    },

    onLoad () {
        this.turnType = 1;                     // 转盘当前转动类型 -1:停止转动   0:由慢到快  1:匀速 2:由快到慢
        this.accSpeed = 0.1;                   // 转盘转动加速度
        this.maxSpeed = 15;                     // 转盘最大转动速度
        this.curSpeed = 3;                      // 转盘当前转动速度
        
        this.springback = false;                // 旋转结束是否回弹
        this.finalAngle = 0;                    // 最终结果指定的角度
        this.decAngle = 1*360;                  // 减速旋转两圈
        this.springbackAngle = 0;               // 回弹角度
        this.duration = 1;                      // 减速持续时间

        this.isShow = true;                     // 是否可以打开静态广告

        this.fishInfo = cc.common.fileOperation.getBankFishInfo();
        
        cc.common.data.requestSeverDataTurnTable((data) => {
            console.log(`----------请求抽奖数据------------：${JSON.stringify(data)}`);
            this.initTurnTableData(data.result);
        });
        
        cc.common.data.notificationCenter.on(CURRENT_LAYER_EXIT, this.btnCloseCallBack.bind(this), this);
    },

    start () {
        this.isOpenLayer = false;
        this.rewardType = 3;// 奖品类型
        this.curDoubleReward = [];
        this.rewardSprList = {                  // 转盘奖品图片资源列表
            "iphone": this.rewardList[0] ,      // iphone 11pro
            "phoneBill": this.rewardList[1] ,   // 话费
            "rateFlow": this.rewardList[2] ,    // 流量
            "redPacket": this.rewardList[3],    // 红包券
            "fish": this.fishSpine,             // 鱼
        };

        this.rewardFragmentSprList = {          // 碎片资源列表
            "iphone": this.rewardFragmentSpr[0] ,
            "phoneBill": this.rewardFragmentSpr[1] ,
            "rateFlow": this.rewardFragmentSpr[2] ,
            "redPacket": this.rewardFragmentSpr[3],
            "fish": this.fishSpine,
        };
        this.fishSpine.getComponent(sp.Skeleton).skeletonData = cc.common.fishSpineAniRes["yu_"+this.fishInfo.fishLevel];
        this.fishSpine.getComponent(sp.Skeleton).setAnimation(0, "swimming", true);

        this.showTodyRewardInfo();
        this.addTurnTableAni(true);
    },

    // 根据服务端数据，初始化前端数据
    initTurnTableData: function (data) {
        this.turnTableInfo = cc.common.fileOperation.getTurnTableInfo();
        this.showExtraFunction = data.showExtraFunction;
        if (this.turnTableInfo.endDate) {
            let time1 = this.getTodayTime(this.turnTableInfo.endDate);
            let time2 = this.getTodayTime(data.config.startDate);
            if (time2 > time1) { // 开启新一轮活动，重置转盘本地数据缓存
                this.resetTurnTableData(data);
            }
        }
        else {
            this.resetTurnTableData(data);
        }

        let time1 = this.getTodayTime();
        if (time1 != this.turnTableInfo.todayDate) { // 需要第二天重置的数据
            // this.turnTableInfo.manualBottleNum = data.config.dayAddEnergyTimes;// 每日剩余体力瓶次数
            this.turnTableInfo.todayDate = time1;
            this.turnTableInfo.doubleNum = data.config.dayTripleTimes;// 每日视频翻倍次数
            this.turnTableInfo.totalLotteryNum = 0;// 每日总抽奖次数
            /**
             * 每日额外奖励领取状况
             * 0 未领取
             * 1 只领取了第一个
             * 2 只领取了第二个
             * 3 两个都已领取
             **/
            this.turnTableInfo.receiveType = 0;
            cc.common.fileOperation.setTurnTableInfo(this.turnTableInfo);
        }
        let itemList = data.config.itemList;
        this.prizeInfo = [];
        for (let i = 0;i < itemList.length;++ i) {
            let tmp = {};
            tmp.name = itemList[i].name;                    // 奖品名称
            tmp.curNum = this.turnTableInfo.prizeNum[i];    // 奖品抽中的碎片数目
            tmp.double = 3;                                 // 看视频翻倍的倍数
            tmp.needNum = itemList[i].num;                  // 奖品碎片上限
            tmp.reward = itemList[i].reward;                // 游戏中道具
            tmp.type = itemList[i].type;                    // 当前奖品类型 0 碎片 其他游戏中的道具
            tmp.index = itemList[i].id;                     // 当前奖品索引
            tmp.icon = itemList[i].icon;                    // 奖品对应图标名称
            if (tmp.type == 1) tmp.icon = "fish";
            if (tmp.type == 2) tmp.icon = "redPacket";
            this.prizeInfo.push(tmp);
        }
        this.updatePrizeInfo();
        this.updateProgressBar();
        this.setStartTurnBtn();
        this.initAwardList(this.prizeInfo);
        let lab = this.nodeTurn.getChildByName("lab");
        lab.getComponent(cc.Label).string = "剩余次数：" + this.turnTableInfo.residueDegree;
    },

    // 重置转盘数据
    resetTurnTableData: function (data) {
        this.turnTableInfo.todayDate = this.getTodayTime();
        this.turnTableInfo.startDate = data.config.startDate;
        this.turnTableInfo.endDate = data.config.endDate;
        this.turnTableInfo.residueDegree = data.config.initialEnergy;
        this.turnTableInfo.prizeNum = [0 ,0 ,0 ,0 ,0 ,0];
        this.turnTableInfo.manualBottleNum = data.config.dayAddEnergyTimes;
        this.turnTableInfo.doubleNum = data.config.dayTripleTimes;
        this.turnTableInfo.luckyTaskNum = data.config.extraChestTimes;
        this.turnTableInfo.totalLotteryNum = 0;
        this.turnTableInfo.receiveType = 0;
        cc.common.fileOperation.setTurnTableInfo(this.turnTableInfo);
    },

    // 获取时间戳
    getTodayTime: function (time) {
        if (!time) {
            let date = new Date();
            let year = date.getFullYear();
            let month = date.getMonth() + 1;
            let day = date.getDate();
            time = [year, month, day].join('-');
        }
        time = time + " " + "07:00:00";
        return new Date(time).getTime();
    },

    // 初始化奖品列表
    initAwardList: function (data) {
        for (let i = 0;i < data.length;++ i) {
            let node = null;
            if(i==0)
            {
                node = this.rewardItemNode;
            }else{
                node = cc.instantiate(this.rewardItemNode);
                node.parent = this.turnSpr;
            }
            node.angle = -i*60;
            if(data[i].type == 1)//鱼
            {
                node.getChildByName("lab").getComponent(cc.Label).string = data[i].name + `*${data[i].reward}`;
                node.getChildByName("spr").active = false;
                node.getChildByName("spine_node").getComponent(sp.Skeleton).skeletonData = cc.common.fishSpineAniRes["yu_"+this.fishInfo.fishLevel];
                node.getChildByName("spine_node").getComponent(sp.Skeleton).setAnimation(0, "swimming", true);
            }else if(data[i].type == 2){//红包券
                node.getChildByName("lab").getComponent(cc.Label).string = data[i].name + `*${data[i].reward}`;
                node.getChildByName("spr").getComponent(cc.Sprite).spriteFrame = this.rewardSprList[data[i].icon];
                node.getChildByName("spr").scale = 1.5;
            }else{
                node.getChildByName("lab").getComponent(cc.Label).string = data[i].name;
            }
        }
    },

    // 展示每日中奖信息
    showTodyRewardInfo: function () {
        let randomRewardList = ["100元话费" ,"10G流量" ,"iphone 11pro"];
        let nameList = cc.common.tool.getCommonNameList();
        let nickNameLen = nameList.length;
        let index = 1;
        let initInfo = (node) => {
            let info = "恭喜用户Elline今日获得红包券*200";
            let name = nameList[Math.floor(Math.random() * (nickNameLen - 1))] || "";
            let newName = "";
            for (let i = 0;i < name.length - 1;++ i) {
                newName += "*";
            }
            newName += name.substring(name.length - 1 ,name.length);
            let rand = Math.random() * 50;
            if (rand <= 1) {
                let randomNum = Math.floor(Math.random() * randomRewardList.length);
                let randomReward = randomRewardList[randomNum] || randomRewardList[0];
                info = `恭喜用户 ${newName} 今日获得${randomReward}`;
            }
            else {
                info = `恭喜用户 ${newName} 今日获得红包券*200`;
            }
            node.getComponent(cc.Label).string = info;
        };
        initInfo(this.nodeMask.getChildByName(`reward_info1`));
        let showAni = () => {
            let rewardInfo = this.nodeMask.getChildByName(`reward_info${index}`);
            cc.tween(rewardInfo)
                .by(0.5 ,{position: cc.v2(0 ,40)})
                .start();
            let index1 = index == 1 ? 2 : 1;
            let rewardInfo1 = this.nodeMask.getChildByName(`reward_info${index1}`);
            initInfo(rewardInfo1);
            cc.tween(rewardInfo1)
                .to(0.5 ,{position: cc.v2(0 ,0)})
                .delay(2)
                .call(() => {
                    rewardInfo.y = -45;
                    index = index1;
                    showAni();
                })
                .start();
        };
        showAni();
    },

    // 转盘灯光
    addLightAni: function (type) {
        let light1 = this.nodeTurn.getChildByName("light");
        let light2 = this.nodeTurn.getChildByName("light1");
        if (!type) {
            light1.stopAllActions();
            light1.opacity = 255;
            light2.opacity = 0;
            return;
        }
        cc.tween(light1)
            .repeatForever(
                cc.tween()
                    .delay(0.2)
                    .call(function () {
                        light1.opacity = light1.opacity == 0 ? 255 : 0;
                        light2.opacity = light2.opacity == 0 ? 255 : 0;
                    })
            )
            .start();
    },

    // 转盘转动
    addTurnTableAni: function (type) {
        this.nodeTurn.getChildByName("hand").active = type;
    },

    // 展示抽奖结果
    showLotteryResults: function () {
        this.playStaticAd();
        this.addTurnTableAni(true);
        this.isOpenLayer = false;
        this.nodeTip.active = true;//结果显示
        this.nodeTip.getChildByName("bg").getComponent(cc.Animation).play();

        let prize = this.prizeInfo[this.rewardType].index;
        let bg = this.nodeTip.getChildByName("bg");

        // let pro = bg.getChildByName("red_bg").getChildByName("progress");
        // pro.active = this.prizeInfo[this.rewardType].type == 0;
        // let red = bg.getChildByName("red");
        // if(this.prizeInfo[this.rewardType].type==1)
        // {//鱼
        //     red.active = false;
        //     bg.getChildByName("red_bg").getChildByName("tips").active = false;
        //     bg.getChildByName("spine_fish").getComponent(sp.Skeleton).skeletonData = cc.common.fishSpineAniRes["yu_"+this.fishInfo.fishLevel];
        //     bg.getChildByName("spine_fish").getComponent(sp.Skeleton).setAnimation(0, "swimming", true);
        // }else if(this.prizeInfo[this.rewardType].type==2)
        // {//红包
        //     bg.getChildByName("red_bg").getChildByName("tips").active = false;
        //     red.getComponent(cc.Sprite).spriteFrame = this.rewardFragmentSprList[this.prizeInfo[i].icon];
        // }else{
        //     red.getChildByName("lab").getComponent(cc.Label).string = this.prizeInfo[i].name + "碎片";
        //     pro.active = true;
        //     bg.getChildByName("red_bg").getChildByName("tips").active = true;
        //     red.getComponent(cc.Sprite).spriteFrame = this.rewardFragmentSprList[this.prizeInfo[i].icon];

        //     this.curDoubleReward = [];
        //             this.curDoubleReward.push({index: i ,num: 1});
        //             this.prizeInfo[i].curNum ++;
        //             let fragment = this.rewardFragmentSprList[this.prizeInfo[i].icon];
        // }


        if (prize > 0) {
            bg.getChildByName("red_bg").active = true;
            bg.getChildByName("continue").active = false;
            let red = bg.getChildByName("red_bg");
            for (let i = 0 ,len = this.prizeInfo.length;i < len;++ i) {
                if (this.prizeInfo[i].index == prize) {

                    let pro = bg.getChildByName("red_bg").getChildByName("progress");
                    if (this.prizeInfo[i].type != 0) {
                        this.updateGameData(this.prizeInfo[i].icon ,this.prizeInfo[i].type ,this.prizeInfo[i].reward);
                        red.getChildByName("lab").getComponent(cc.Label).string = this.prizeInfo[i].name + "*" + this.prizeInfo[i].reward;
                        pro.active = false;
                        bg.getChildByName("red_bg").getChildByName("tips").active = false;
                    }
                    else {
                        red.getChildByName("lab").getComponent(cc.Label).string = this.prizeInfo[i].name + "碎片";
                        pro.active = true;
                        bg.getChildByName("red_bg").getChildByName("tips").active = true;
                    }
                    this.curDoubleReward = [];
                    this.curDoubleReward.push({index: i ,num: 1});
                    this.prizeInfo[i].curNum ++;
                    let fragment = this.rewardFragmentSprList[this.prizeInfo[i].icon];
                    if (fragment instanceof cc.Node) {
                        if (!red.getChildByName("fish")) {
                            let fish = cc.instantiate(fragment);
                            red.getChildByName("red").active = false;
                            fish.parent = red;
                            fish.position = cc.v2(0 ,0);
                            fish.active = true;
                        }
                    }
                    else {
                        if (red.getChildByName("fish")) red.getChildByName("fish").removeFromParent();
                        red.getChildByName("red").active = true;
                        red.getChildByName("red").getComponent(cc.Sprite).spriteFrame = fragment;
                        if (this.prizeInfo[i].icon == "redPacket") {
                            red.getChildByName("red").scale = 2;
                        }
                        else {
                            red.getChildByName("red").scale = 1;
                        }
                    }
                    pro.getChildByName("bar").getComponent(cc.Sprite).fillRange = this.prizeInfo[i].curNum / this.prizeInfo[i].needNum;
                    pro.getChildByName("lab").getComponent(cc.Label).string = `${this.prizeInfo[i].curNum}/${this.prizeInfo[i].needNum}`;
                    break;
                }
            }
            let btnBg = red.getChildByName("btn_ok").getChildByName("bg");
            let lab = btnBg.getChildByName(`lab`);
            let visible = (this.prizeInfo[this.rewardType].double > 1 && this.turnTableInfo.doubleNum > 0);
            lab.active = visible;
            btnBg.getChildByName(`lab1`).active = visible;
            btnBg.getChildByName(`lab2`).active = visible;
            btnBg.getChildByName(`lab3`).active = !visible;
            if (visible) {
                lab.getComponent(cc.Label).string = this.prizeInfo[this.rewardType].double;
            }
        }
        else {
            bg.getChildByName("red_bg").active = false;
            bg.getChildByName("continue").active = true;
        }
        bg.getComponent(cc.Animation).play();
    },

    // 置灰开始抽奖按钮
    setStartTurnBtn: function () {
        if (this.turnTableInfo.residueDegree <= 0) {
            this.nodeTurn.getChildByName("btn_turn").active = false;
            this.nodeTurn.getChildByName("btn_turn1").active = true;
        }
        else {
            this.nodeTurn.getChildByName("btn_turn").active = true;
            this.nodeTurn.getChildByName("btn_turn1").active = false;
        }
    },

    // 更新进度条
    updateProgressBar: function () {
        let bar = this.progressBar.getChildByName("bar");
        let fillRange = this.turnTableInfo.totalLotteryNum >= 10 ? 1 : this.turnTableInfo.totalLotteryNum / 10;
        bar.getComponent(cc.Sprite).fillRange = fillRange;
        this.updateBoxStatus();
    },

    // 更新额外宝箱状态
    updateBoxStatus: function () {
        let btn1 = this.progressBar.getChildByName("box1");
        let btn2 = this.progressBar.getChildByName("box2");
        let sprType = [[0 ,2] ,[1 ,2] ,[0 ,3] ,[1 ,3]];
        let receiveType = this.turnTableInfo.receiveType;
        btn1.getComponent(cc.Sprite).spriteFrame = this.boxSpr[sprType[receiveType][0]];
        btn2.getComponent(cc.Sprite).spriteFrame = this.boxSpr[sprType[receiveType][1]];
    },

    // 更新奖品信息
    updatePrizeInfo: function () {
        let nodeList = {
            "iphone": [this.nodePrize.getChildByName(`prize1`) ,this.rewardList[0]] ,
            "phoneBill": [this.nodePrize.getChildByName(`prize2`) ,this.rewardList[1]] ,
            "rateFlow": [this.nodePrize.getChildByName(`prize3`) ,this.rewardList[2]] ,
        };
        for (let i = 0 ,len = this.prizeInfo.length;i < len;++ i) {
            if (this.prizeInfo[i].type != 0) continue;
            let prize = nodeList[this.prizeInfo[i].icon][0];
            if (!prize) continue;
            prize.getChildByName(`spr`).getComponent(cc.Sprite).spriteFrame = nodeList[this.prizeInfo[i].icon][1];
            prize.getChildByName("lab").getComponent(cc.Label).string = this.prizeInfo[i].name;
            let pro = prize.getChildByName("progress");
            pro.getChildByName("bar").getComponent(cc.Sprite).fillRange = this.prizeInfo[i].curNum / this.prizeInfo[i].needNum;
            pro.getChildByName("lab").getComponent(cc.Label).string = `${this.prizeInfo[i].curNum}/${this.prizeInfo[i].needNum}`;
        }
    },

    // 更新宝箱界面信息
    updateBoxInfo: function (startPosX ,prizeList ,len ,btn) {
        let boxAni = cc.instantiate(this.boxPrefab);
        boxAni.parent = btn.target;
        boxAni.position = cc.v2(0 ,0);
        let tmp = 0;
        len == 2 ? (tmp = 0) : (tmp = 2);
        boxAni.getChildByName("xingyun_icon_zibaoxiang1").getComponent(cc.Sprite).spriteFrame = this.boxSpr[0 + tmp];
        boxAni.getChildByName("xingyun_icon_zibaoxiang2").getComponent(cc.Sprite).spriteFrame = this.boxSpr[1 + tmp];
        let ani = boxAni.getComponent(cc.Animation);
        ani.play();
        ani.on(`finished` ,() => {
            boxAni.removeFromParent();
            this.updateBoxStatus();
            this.nodeBoxReward.active = true;
            let node = this.nodeBoxReward.getChildByName("node");
            node.getComponent(cc.Animation).play();
            let title = node.getChildByName("title");
            title.getComponent(cc.Sprite).spriteFrame = this.titleSpr[0];
            let titleMask = title.getChildByName("saoguang").getChildByName("guangtiao");
            titleMask.getComponent(cc.Mask).spriteFrame = this.titleLightSpr[0];
            titleMask.setContentSize(this.titleLightSpr[0]._originalSize);
            title.getChildByName("saoguang").getComponent(cc.Animation).play();

            this.curDoubleReward = [];
            let parent = node.getChildByName("bg");
            parent.removeAllChildren();
            let iconNode = node.getChildByName("icon");
            let minNum = null;
            let posX = startPosX;
            let random = Math.floor(Math.random() * prizeList.length);
            for (let i = 0;i < len;++ i) {
                let cloneIcon = cc.instantiate(iconNode);
                cloneIcon.parent = parent;
                cloneIcon.position = cc.v2(posX ,20);
                cloneIcon.active = true;
                posX += 230;
                let prize = prizeList[(i + random) % prizeList.length];
                let fragment = this.rewardFragmentSprList[this.prizeInfo[prize].icon];
                if (fragment instanceof cc.Node) {
                    if (!cloneIcon.getChildByName("fish")) {
                        cloneIcon.getChildByName("spr").active = false;
                        let fish = cc.instantiate(fragment);
                        fish.parent = cloneIcon;
                        fish.position = cc.v2(0 ,0);
                        fish.active = true;
                    }
                }
                else {
                    cloneIcon.getChildByName("spr").active = true;
                    if (cloneIcon.getChildByName("fish")) cloneIcon.getChildByName("fish").removeFromParent();
                    if (this.prizeInfo[prize].icon == "redPacket") {
                        cloneIcon.getChildByName("spr").scale = 2;
                    }
                    else {
                        cloneIcon.getChildByName("spr").scale = 1;
                    }
                    cloneIcon.getChildByName("spr").getComponent(cc.Sprite).spriteFrame = fragment;
                }
                if (this.prizeInfo[prize].type != 0) {
                    cloneIcon.getChildByName("lab").getComponent(cc.Label).string = this.prizeInfo[prize].name + `*${this.prizeInfo[prize].reward}`;
                }
                else {
                    cloneIcon.getChildByName("lab").getComponent(cc.Label).string = this.prizeInfo[prize].name + "碎片*1";
                }
                this.turnTableInfo.prizeNum[prize] ++;
                this.prizeInfo[prize].curNum ++;
                if (this.prizeInfo[prize].type != 0) {
                    this.updateGameData(this.prizeInfo[prize].icon ,this.prizeInfo[prize].type ,this.prizeInfo[prize].reward);
                }
                let num = this.prizeInfo[prize].needNum - this.turnTableInfo.prizeNum[prize];
                this.prizeInfo[prize].double = num >= 3 ? 3 : num;
                if (minNum == null) {
                    minNum = this.prizeInfo[prize].double;
                }
                else if (this.prizeInfo[prize].double < minNum) {
                    minNum = this.prizeInfo[prize].double;
                }
                this.curDoubleReward.push({index: prize ,num: minNum});
            }
            cc.common.fileOperation.setTurnTableInfo(this.turnTableInfo);
            let btnBg = node.getChildByName(`btn_playAd`).getChildByName(`bg`);
            let lab = btnBg.getChildByName(`lab`);
            let btnGet = node.getChildByName("btn_playAd");
            let visible = (minNum >= 2 && this.turnTableInfo.doubleNum > 0);
            lab.active = visible;
            btnBg.getChildByName(`lab1`).active = visible;
            btnBg.getChildByName(`lab2`).active = visible;
            btnBg.getChildByName(`lab3`).active = !visible;
            btnBg.getChildByName(`lab3`).type = 0;
            if (visible) {
                lab.getComponent(cc.Label).string = minNum;
            }
            btnGet.active = !this.turnTableInfo.doubleNum <= 0;
            this.playStaticAd();
        });
    },

    // 展示幸运砸中你界面
    showLuckyLayer: function () {
        this.nodeLucky.active = true;
        this.appInfoList = [
            {name: "微信" ,installType: 0 ,isComplete: false ,box1State: -1 ,box2State: -1} ,
            {name: "QQ" ,installType: 1 ,isComplete: false ,box1State: 0 ,box2State: -1} ,
            {name: "支付宝" ,installType: 2 ,isComplete: true ,box1State: 1 ,box2State: 0} ,
            {name: "绝地求生" ,installType: 2 ,isComplete: true ,box1State: 1 ,box2State: 1} ,
            {name: "英雄联盟" ,installType: 0 ,isComplete: false ,box1State: -1 ,box2State: -1} ,
            {name: "钉钉" ,installType: 1 ,isComplete: false ,box1State: 1 ,box2State: -1} ,
            {name: "滴滴" ,installType: 2 ,isComplete: true ,box1State: 1 ,box2State: 1} ,
            {name: "爱奇艺" ,installType: 2 ,isComplete: true ,box1State: 0 ,box2State: 0} ,
            {name: "腾讯视频" ,installType: 1 ,isComplete: false ,box1State: 0 ,box2State: -1} ,
            {name: "优酷" ,installType: 2 ,isComplete: true ,box1State: 0 ,box2State: 1} ,
        ];
        /**
         * 排序
         * 已安装、试玩均未领取 > 已安装、试玩领取一个 > 未安装 > 已安装未领取、未试玩
         * > 已安装已领取、未试玩 > 已安装、已试玩全部领取
         **/
        this.appInfoList.sort((a ,b) => {
            // 已安装 试玩 两个均未领取
            if (a.box1State == 0 && a.box2State == 0 && (b.box1State != 0 || b.box2State != 0)) {
                return -1;
            }
            // 已安装 试玩 两个均未领取
            else if (b.box1State == 0 && b.box2State == 0 && (a.box1State != 0 || a.box2State != 0)) {
                return 1;
            }
            // 已安装 试玩 领取了一个
            else if (((a.box1State == 0 && a.box2State == 1) || (a.box1State == 1 && a.box2State == 0))
                && (b.box1State != 0 && b.box2State != 0)) {
                return -1;
            }
            // 已安装 试玩 领取了一个
            else if (((b.box1State == 0 && b.box2State == 1) || (b.box1State == 1 && b.box2State == 0))
                && (a.box1State != 0 && a.box2State != 0)) {
                return 1;
            }
            // 未安装
            else if (a.box1State == -1 && b.box1State != -1) {
                return -1;
            }
            // 未安装
            else if (b.box1State == -1 && a.box1State != -1) {
                return 1;
            }
            // 已安装 未领取 未试玩
            else if (a.box1State == 0 && a.box2State == -1 && b.box1State == 1 &&
                (b.box2State == -1 || b.box2State == 1)) {
                return -1;
            }
            // 已安装 未领取 未试玩
            else if (b.box1State == 0 && b.box2State == -1 && a.box1State == 1 &&
                (a.box2State == -1 || a.box2State == 1)) {
                return 1;
            }
            // 已安装 已领取 未试玩
            else if (a.box1State == 1 && a.box2State == -1 && b.box1State == 1 && b.box2State == 1) {
                return -1;
            }
            // 已安装 已领取 未试玩
            else if (b.box1State == 1 && b.box2State == -1 && a.box1State == 1 && a.box2State == 1) {
                return 1;
            }
            else {
                return -1;
            }
        });
        let content = cc.find("node/scrollview/view/content" ,this.nodeLucky);
        let item = this.nodeLucky.getChildByName("node").getChildByName("item");
        content.height = this.appInfoList.length * 210;
        let posY = -105;
        for (let i = 0 ,len = this.appInfoList.length;i < len;++ i) {
            let itemClone = cc.instantiate(item);
            itemClone.parent = content;
            itemClone.active = true;
            itemClone.y = posY;
            itemClone.getChildByName("lab").getComponent(cc.Label).string = this.appInfoList[i].name;
            let pro = this.appInfoList[i].installType / 2;
            let bar = itemClone.getChildByName("progress").getChildByName("bar");
            bar.getComponent(cc.Sprite).fillRange = pro;
            let btn1 = itemClone.getChildByName("progress").getChildByName("btn1");
            let btn2 = itemClone.getChildByName("progress").getChildByName("btn2");
            btn1.getComponent(cc.Button).interactable = this.appInfoList[i].installType >= 1;
            btn2.getComponent(cc.Button).interactable = this.appInfoList[i].installType == 2;
            if (this.appInfoList[i].box1State >= 0) {
                let box1State = this.appInfoList[i].box1State ? "已领取" : "未领取";
                btn1.getChildByName("lab").getComponent(cc.Label).string = box1State;
            }
            else {
                btn1.getChildByName("lab").getComponent(cc.Label).string = "安装";
            }
            if (this.appInfoList[i].box2State >= 0) {
                let box2State = this.appInfoList[i].box2State ? "已领取" : "未领取";
                btn2.getChildByName("lab").getComponent(cc.Label).string = box2State;
            }
            else {
                btn2.getChildByName("lab").getComponent(cc.Label).string = "试玩";
            }

            let btnComplete = itemClone.getChildByName("btn_complete");
            let completeLab = btnComplete.getChildByName("bg").getChildByName("lab");
            let str = this.appInfoList[i].isComplete ? `已完成` : `去完成`;
            completeLab.getComponent(cc.Label).string = str;
            btnComplete.on("click" ,(event) => {
                if (this.appInfoList[i].isComplete) {
                    cc.common.tool.showWordTips("已完成" ,false);
                }
                else {
                    cc.common.tool.showWordTips("去完成" ,false);
                }
            });
            posY -= 210;
        }
    },

    // 获取可以获取的奖品列表
    getCanObtainPrizeList: function () {
        let prizeList = [];
        for (let i = 0,len = this.turnTableInfo.prizeNum.length;i < len;++ i) {
            if (this.turnTableInfo.prizeNum[i] < this.prizeInfo[i].needNum - 1) {
                prizeList.push(i);
            }
        }
        return prizeList;
    },

    /**
     * @brief 如果抽中的是游戏中的道具，更新游戏数据
     * @param type 游戏道具类型
     * @param double 倍数
     * @param num 基础奖励数目
     **/
    updateGameData: function (type ,double ,num) {
        console.log("----type--double--num----:"+type+"::"+double+"::"+num);
        if(type==1)
        {
            this.fishInfo.bankTotalNum+=num*double;
            cc.common.fileOperation.setBankFishInfo(this.fishInfo);
            cc.GameScene.updateFishBankInfo();
        }
        if(type==2)
        {
            cc.GameScene.setPlayerRedCouponNum(double*num);
        }
    },

    // 播放静态广告
    playStaticAd: function () {
        if (!this.isShow) return;
        cc.common.tool.playSubLayerStaticAd(this.isShow ,function (data) {
        }.bind(this));
        this.isShow = false;
    },

    // 关闭静态广告
    closeStaticAd: function () {
        if (!this.isShow) {
            cc.common.tool.playSubLayerStaticAd(this.isShow ,function (data) {
            }.bind(this));
            this.isShow = true;
        }
    },

    // 播放广告
    playAd: function (callBack) {
        cc.common.tool.playVideoAd(callBack, (data) => { // 播放广告失败
            console.log(`----------播放广告失败-----------：${JSON.stringify(data)}`);
        } ,false)
    } ,

    /**----------------------按钮点击事件处理 START-------------------------**/
    // 打开规则界面
    btnRuleClick: function () {
        if (this.isOpenLayer) return;
        this.isOpenLayer = true;
        this.nodeRule.active = true;
        this.nodeRule.getChildByName("bg").getComponent(cc.Animation).play();
        this.playStaticAd();
    },

    // 关闭规则界面
    btnCloseRuleClick: function () {
        this.isOpenLayer = false;
        this.nodeRule.active = false;
        this.closeStaticAd();
    },

    // 打开体力瓶界面
    btnManualBottleClick: function () {
        if (this.isOpenLayer) return;
        this.isOpenLayer = true;
        this.nodeBottle.active = true;
        this.nodeBottle.getChildByName("bg").getComponent(cc.Animation).play();
        if (this.turnTableInfo.manualBottleNum <= 0) {
            let title = this.nodeBottle.getChildByName("bg").getChildByName("title");
            title.getComponent(cc.Label).string = "次数已用完，明天再来吧!";
        }
        this.playStaticAd();
    },

    // 关闭体力瓶界面
    btnCloseManualBottleClick: function () {
        this.nodeBottle.active = false;
        this.isOpenLayer = false;
        this.closeStaticAd();
    },

    // 体力瓶界面 立即获取（观看广告）
    btnGetClick: function () {
        if (this.turnTableInfo.manualBottleNum <= 0) {
            cc.common.tool.showWordTips(`次数已用完`);
            return;
        }
        this.playAd(() => {
            this.turnTableInfo.residueDegree += 4;
            this.nodeBottle.active = false;
            this.isOpenLayer = false;
            let lab = this.nodeTurn.getChildByName("lab");
            lab.getComponent(cc.Label).string = "剩余免费次数：" + this.turnTableInfo.residueDegree + "次";
            this.turnTableInfo.manualBottleNum --;
            cc.common.fileOperation.setTurnTableInfo(this.turnTableInfo);
            this.setStartTurnBtn();
        });
    },

    // 转盘抽奖按钮
    btnStartTurn: function () {
        if (this.turnType != 1 || this.turnTableInfo.residueDegree <= 0) return;

        this.isOpenLayer = true;
        this.addTurnTableAni(false);

        let prizeList = this.getCanObtainPrizeList();
        if (prizeList.length <= 0) return;
        this.curDoubleReward = [];
        let index = Math.floor(Math.random() * prizeList.length);
        this.rewardType = prizeList[index];
        console.log("==转盘抽奖按钮=this.rewardType=", this.rewardType)
        this.turnTableInfo.prizeNum[this.rewardType] ++;
        let num = this.prizeInfo[this.rewardType].needNum - this.turnTableInfo.prizeNum[this.rewardType];
        this.prizeInfo[this.rewardType].double = num >= 3 ? 3 : num;
        this.stopAngle = this.rewardType * this.gearAngle;


        this.turnTableInfo.residueDegree --;
        this.turnTableInfo.totalLotteryNum ++;
        cc.common.fileOperation.setTurnTableInfo(this.turnTableInfo);
        let lab = this.nodeTurn.getChildByName("lab");
        lab.getComponent(cc.Label).string = "剩余免费次数：" + this.turnTableInfo.residueDegree + "次";
        this.defaultAngle = 30;//Math.floor(Math.random() * 40);
        this.springbackAngle = Math.ceil(Math.random() * 3);
        if (this.springbackAngle == 0) this.springbackAngle = 1;


        this.turnType = 0;
    } ,

    // 打开额外奖励界面
    btnBonusClick1: function (btn) {
        if (this.isOpenLayer) return;
        this.isOpenLayer = true;
        let name = btn.target.name;
        let prizeList = this.getCanObtainPrizeList();
        if (prizeList.length < 2) return;
        if (this.turnTableInfo.totalLotteryNum >= 5 || name == "btn1" || name == "btn2") {
            if (this.turnTableInfo.receiveType == 1 || this.turnTableInfo.receiveType == 3) {
                cc.common.tool.showWordTips("该宝箱已领取!" ,false);
                return;
            }
            if (this.turnTableInfo.receiveType == 0) {
                this.turnTableInfo.receiveType = 1;
            }
            else if (this.turnTableInfo.receiveType == 2) {
                this.turnTableInfo.receiveType = 3;
            }
            this.updateBoxInfo(-115 ,prizeList ,2 ,btn);
        }
        else if (this.turnTableInfo.totalLotteryNum < 5) {
            cc.common.tool.showWordTips("抽奖次数不够哦，快去抽奖吧!" ,false);
        }
    },
    btnBonusClick2: function (btn) {
        if (this.isOpenLayer) return;
        this.isOpenLayer = true;
        let name = btn.target.name;
        let prizeList = this.getCanObtainPrizeList();
        if (prizeList.length < 3) return;
        if (this.turnTableInfo.totalLotteryNum >= 10 || name == "btn1" || name == "btn2") {
            if (this.turnTableInfo.receiveType == 2 || this.turnTableInfo.receiveType == 3) {
                cc.common.tool.showWordTips("该宝箱已领取!" ,false);
                return;
            }
            if (this.turnTableInfo.receiveType == 0) {
                this.turnTableInfo.receiveType = 2;
            }
            else if (this.turnTableInfo.receiveType == 1) {
                this.turnTableInfo.receiveType = 3;
            }
            this.updateBoxInfo(-230 ,prizeList ,3 ,btn);
        }
        else if (this.turnTableInfo.totalLotteryNum < 10) {
            cc.common.tool.showWordTips("抽奖次数不够哦，快去抽奖吧!" ,false);
        }
    },

    // 关闭额外奖励界面
    btnCloseBonusClick: function () {
        this.nodeBoxReward.active = false;
        this.isOpenLayer = false;
        let node = this.nodeBoxReward.getChildByName("node");
        if (cc.find("btn_playAd/bg/lab3" ,node).type == 1) {
            this.btnCloseDoubleLayer();
        }
        else {
            this.updatePrizeInfo();
            this.closeStaticAd();
        }
    },

    // 打开宝箱奖励翻倍界面
    btnBoxRewardDoubleClick: function () {
        this.nodeBoxReward.active = true;
        let node = this.nodeBoxReward.getChildByName("node");
        if (cc.find("btn_playAd/bg/lab3" ,node).type == 1) {
            this.btnCloseDoubleLayer();
        }
        else {
            node.getComponent(cc.Animation).play();
            let title = node.getChildByName("title");
            title.getComponent(cc.Sprite).spriteFrame = this.titleSpr[1];
            let titleMask = title.getChildByName("saoguang").getChildByName("guangtiao");
            titleMask.getComponent(cc.Mask).spriteFrame = this.titleLightSpr[1];
            titleMask.setContentSize(this.titleLightSpr[1]._originalSize);
            title.getChildByName("saoguang").getComponent(cc.Animation).play();

            let btnBg = node.getChildByName(`btn_playAd`).getChildByName(`bg`);
            let lab = btnBg.getChildByName(`lab`);
            lab.active = false;
            btnBg.getChildByName(`lab1`).active = false;
            btnBg.getChildByName(`lab2`).active = false;
            btnBg.getChildByName(`lab3`).active = true;
            btnBg.getChildByName(`lab3`).type = 1;

            let child = node.getChildByName("bg").children;
            for (let i = 0;i < child.length;++ i) {
                let str = child[i].getChildByName("lab").getComponent(cc.Label).string;
                let strArr = str.split(`*`);
                let str1 = lab.getComponent(cc.Label).string;
                str = strArr[0] + `*` +parseInt(strArr[1]) * parseInt(str1);
                child[i].getChildByName("lab").getComponent(cc.Label).string = str;
            }
        }
    },

    // 看视频翻倍按钮
    btnDoubleWatchingvideoClick: function () {
        if (this.isOpenLayer) return;
        this.playAd(() => {
            this.isOpenLayer = true;
            this.btnClose1();
            this.nodeDouble.active = true;
            this.nodeDouble.getChildByName("node").getComponent(cc.Animation).play();
            this.turnTableInfo.doubleNum --;
            cc.common.fileOperation.setTurnTableInfo(this.turnTableInfo);
            let icon = this.nodeDouble.getChildByName("node").getChildByName("icon");
            let info = this.prizeInfo[this.curDoubleReward[0].index];
            let fragment = this.rewardFragmentSprList[info.icon];
            if (fragment instanceof cc.Node) {
                if (!icon.getChildByName("fish")) {
                    let fish = cc.instantiate(fragment);
                    icon.getChildByName("spr").active = false;
                    fish.parent = icon;
                    fish.position = cc.v2(0 ,0);
                    fish.active = true;
                }
            }
            else {
                if (icon.getChildByName("fish")) icon.getChildByName("fish").removeFromParent();
                icon.getChildByName("spr").getComponent(cc.Sprite).spriteFrame = fragment;
                icon.getChildByName("spr").active = true;
                if (info.icon == "redPacket") {
                    icon.getChildByName("spr").scale = 2;
                }
                else {
                    icon.getChildByName("spr").scale = 1;
                }
            }
            if (this.turnTableInfo.doubleNum <= 0 || info.double <= 0) {
                if (info.type != 0) {
                    icon.getChildByName("lab").getComponent(cc.Label).string = `x${info.reward}`;
                }
                else {
                    icon.getChildByName("lab").getComponent(cc.Label).string = `x1`;
                }
                this.curDoubleReward[0].num = 1;
            }
            else if (info.double > 0) {
                if (info.type != 0) {
                    icon.getChildByName("lab").getComponent(cc.Label).string = `x${info.double * info.reward}`;
                }
                else {
                    icon.getChildByName("lab").getComponent(cc.Label).string = `x${info.double}`;
                }
                this.curDoubleReward[0].num = info.double;
            }
            this.playStaticAd();
        });
    },

    // 关闭翻倍奖励界面
    btnCloseDoubleLayer: function () {
        this.nodeDouble.active = false;
        this.isOpenLayer = false;
        if (this.nodeBoxReward.active) {
            this.nodeBoxReward.active = false;
        }
        if (this.turnTableInfo.doubleNum > 0) {
            for (let i = 0;i < this.curDoubleReward.length;++ i) {
                let index = this.curDoubleReward[i].index;
                if (this.prizeInfo[index].type != 0) {
                    this.updateGameData(this.prizeInfo[index].icon ,this.curDoubleReward[i].num - 1 ,this.prizeInfo[index].reward);
                }
                this.prizeInfo[index].curNum += this.curDoubleReward[i].num - 1;
                this.turnTableInfo.prizeNum[index] += this.curDoubleReward[i].num - 1;
                let num = this.prizeInfo[index].needNum - 1 - this.turnTableInfo.prizeNum[index];
                this.prizeInfo[index].double = num >= 3 ? 3 : num;
                cc.common.fileOperation.setTurnTableInfo(this.turnTableInfo);
            }
        }
        this.updatePrizeInfo();
        this.closeStaticAd();
    } ,

    btnClose: function () {
        if (false && this.showExtraFunction) {
            this.nodeMain.active = false;
            this.showLuckyLayer();
        }
        else {
            this.btnCloseCallBack();
        }
    } ,

    // 关闭抽奖结果展示界面
    btnClose1: function () {
        this.isOpenLayer = false;
        this.nodeTip.active = false;
        this.closeStaticAd();
    } ,

    btnCloseCallBack: function () {
        cc.common.tool.playAudio(cc.common.audioRes['button']);
        cc.common.tool.removeSdkPrefab();
        this.node.destroy();
    },
    /**----------------------按钮点击事件处理 END-------------------------**/

    update (dt) {
        if(this.turnType == -1)
            return;
        if(this.turnType == 1) //匀速
            this.turnSpr.angle -= this.curSpeed;
        if(this.turnType == 0) //加速
        {
            this.turnSpr.angle -= this.curSpeed;
            if(this.curSpeed <= this.maxSpeed) {
                this.curSpeed += this.accSpeed;
            }else {
                this.turnType = 2;
            }
        } 
        if(this.turnType == 2) //减速
        {
            if(this.curSpeed > 0.5) {
                this.curSpeed -= this.accSpeed;
                this.turnSpr.angle -= this.curSpeed;
            }else {
                let angle1 = parseInt(this.turnSpr.angle%360);
                //let index = angle1%60;
                if(this.rewardType<=0)
                {
                    this.turnSpr.angle -= this.turnSpr.angle < this.rewardType*60 ? -0.5: 0.5;
                    if(Math.abs(this.turnSpr.angle - this.rewardType*60)<3)
                    {
                        this.turnSpr.angle = this.rewardType*60;
                        this.rewardType = Math.abs(this.rewardType);
                        this.turnType = -1;
                        console.log("==正确角度=",this.turnSpr.angle+"===",this.rewardType);
                        this.showLotteryResults();
                    }
                }else{
                    console.log("==大约角度=",this.turnSpr.angle+"==最终角度=", angle1+"=this.rewardType=",this.rewardType)
                    this.turnSpr.angle = angle1;
                    this.rewardType = Math.round(angle1/60);//四舍五入
                }
            }
        }    
    },
});
